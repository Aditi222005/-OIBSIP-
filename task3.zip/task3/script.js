// Display current time and date
function updateDateTime() {
    const now = new Date();
    document.getElementById('current-time').textContent = now.toLocaleTimeString();
    document.getElementById('current-date').textContent = now.toLocaleDateString();
}
setInterval(updateDateTime, 1000);

// Temperature conversion logic
function convertTemperature() {
    const tempInput = document.getElementById('temperature').value.trim();
    const inputUnit = document.getElementById('input-unit').value;
    const outputDiv = document.getElementById('output');

    // Validate input
    if (isNaN(tempInput) || tempInput === "") {
        outputDiv.textContent = "Please enter a valid number.";
        return;
    }

    const temp = parseFloat(tempInput);
    let convertedTemp, outputUnit;

    switch (inputUnit) {
        case "Celsius":
            convertedTemp = `${(temp * 9/5 + 32).toFixed(2)} °F (Fahrenheit) and ${(temp + 273.15).toFixed(2)} K (Kelvin)`;
            break;
        case "Fahrenheit":
            convertedTemp = `${((temp - 32) * 5/9).toFixed(2)} °C (Celsius) and ${((temp - 32) * 5/9 + 273.15).toFixed(2)} K (Kelvin)`;
            break;
        case "Kelvin":
            convertedTemp = `${(temp - 273.15).toFixed(2)} °C (Celsius) and ${((temp - 273.15) * 9/5 + 32).toFixed(2)} °F (Fahrenheit)`;
            break;
        default:
            convertedTemp = "Invalid unit selected.";
    }

    outputDiv.textContent = `Converted: ${convertedTemp}`;
}

// Attach event listener to button
document.getElementById('convert-btn').addEventListener('click', convertTemperature);
